import { NextRequest, NextResponse } from "next/server";

const API_BASE = process.env.API_PROXY_URL || "http://localhost:8000";

async function proxyRequest(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  // Path: /api/proxy/modules → strips leading /, gets "modules"
  const path = searchParams.get("path") || "";
  if (!path) {
    return NextResponse.json({ error: "Missing ?path= parameter" }, { status: 400 });
  }

  const targetUrl = `${API_BASE}/api/${path}`;

  try {
    const headers: Record<string, string> = {};
    const contentType = req.headers.get("content-type");
    if (contentType) headers["Content-Type"] = contentType;

    const body = req.method !== "GET" ? await req.text() : undefined;

    const res = await fetch(targetUrl, {
      method: req.method,
      headers,
      body,
    });

    // If SSE stream, forward it directly
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("text/event-stream")) {
      return new NextResponse(res.body, {
        status: res.status,
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    }

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}

export async function GET(req: NextRequest) {
  return proxyRequest(req);
}

export async function POST(req: NextRequest) {
  return proxyRequest(req);
}
